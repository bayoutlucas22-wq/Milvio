import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ArrowLeft,
  BarChart3,
  BrainCircuit,
  CircleDollarSign,
  FileSpreadsheet,
  Gauge,
  Link2,
  RefreshCcw,
  Server,
  ShieldCheck,
  Smartphone,
  Workflow,
} from "lucide-react";
import { Link } from "wouter";

const sections = [
  {
    title: "1. O que o dono ganha",
    icon: BrainCircuit,
    tone: "border-sky-200 bg-sky-50/70",
    points: [
      "A API ajuda a ver se a loja ganhou dinheiro de verdade.",
      "O importante não é só vender. O importante é saber o que sobrou no fim.",
      "A conta precisa ser fácil: quanto entrou, quanto saiu e quanto ficou.",
    ],
  },
  {
    title: "2. Como os dados chegam",
    icon: Server,
    tone: "border-emerald-200 bg-emerald-50/70",
    points: [
      "Hoje a loja pode mandar XLS para o sistema.",
      "No futuro, a API pode trazer esses dados mais rápido e com menos erro.",
      "Pedido, entrega, repasse e perda entram na conta da loja.",
    ],
  },
  {
    title: "3. O caminho do dado",
    icon: Workflow,
    tone: "border-amber-200 bg-amber-50/70",
    points: [
      "A venda acontece no Zé Delivery.",
      "O sistema recebe os dados por planilha ou pela API.",
      "A conta é organizada no banco.",
      "A tela mostra lucro, custo e o que precisa ser corrigido.",
    ],
  },
  {
    title: "4. O que melhora",
    icon: Gauge,
    tone: "border-rose-200 bg-rose-50/70",
    points: [
      "Menos trabalho com planilha.",
      "Menos erro na hora de ler os números.",
      "Mais rapidez para agir no mesmo dia.",
      "Mais chance de proteger o lucro antes dele sumir.",
    ],
  },
];

const compareRows = [
  {
    label: "De onde vem",
    xls: "Planilha baixada",
    api: "Leitura direta da origem",
  },
  {
    label: "Velocidade",
    xls: "Precisa subir arquivo",
    api: "Pode entrar sozinha",
  },
  {
    label: "Chance de erro",
    xls: "Maior, porque alguém mexe na planilha",
    api: "Menor, porque vem direto da fonte",
  },
  {
    label: "Melhor uso",
    xls: "Auditoria e conferência",
    api: "Rotina diária",
  },
  {
    label: "Valor para o dono",
    xls: "Fechar a conta",
    api: "Saber mais cedo onde está ganhando ou perdendo",
  },
];

function SectionCard({
  title,
  icon: Icon,
  tone,
  points,
}: {
  title: string;
  icon: typeof BrainCircuit;
  tone: string;
  points: string[];
}) {
  return (
    <Card className={`rounded-[28px] border shadow-none ${tone}`}>
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-white/80 p-3">
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-xl">{title}</CardTitle>
            <CardDescription>Explicação curta e prática.</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {points.map((point) => (
          <div key={point} className="rounded-2xl bg-white/85 p-4 text-sm leading-6 text-slate-700 shadow-sm">
            {point}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export default function ApiResearch() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff_0%,#f8fafc_42%,#e2e8f0_100%)] px-4 py-6 text-slate-950 sm:px-6">
      <div className="mx-auto flex max-w-6xl flex-col gap-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link href="/">
            <Button variant="outline" size="sm" className="rounded-full bg-white/80 backdrop-blur">
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
          </Link>
          <Badge className="rounded-full bg-slate-950 px-3 py-1 text-slate-50">Pesquisa API</Badge>
        </div>

        <section className="grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="space-y-4">
            <Badge variant="outline" className="rounded-full border-sky-300 bg-white/70 px-3 py-1">
              Zé Delivery • Ambev • Conta da loja
            </Badge>
            <div className="space-y-3">
              <h1 className="max-w-2xl text-4xl font-semibold tracking-tight text-slate-950 sm:text-5xl">
                Como a API ajuda a loja a ganhar mais dinheiro
              </h1>
              <p className="max-w-2xl text-base leading-7 text-slate-600 sm:text-lg">
                A ideia é simples: tirar trabalho da mão, enxergar os números mais cedo e saber com clareza se a loja está lucrando ou só girando venda.
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <Card className="rounded-[26px] border-white/70 bg-white/85 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur">
                <CardContent className="p-5">
                  <CircleDollarSign className="mb-4 h-8 w-8 text-sky-600" />
                  <p className="text-sm text-slate-500">O que importa</p>
                  <p className="mt-1 text-xl font-semibold">Sobra no caixa</p>
                </CardContent>
              </Card>
              <Card className="rounded-[26px] border-white/70 bg-white/85 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur">
                <CardContent className="p-5">
                  <FileSpreadsheet className="mb-4 h-8 w-8 text-emerald-600" />
                  <p className="text-sm text-slate-500">Hoje</p>
                  <p className="mt-1 text-xl font-semibold">Planilha + banco</p>
                </CardContent>
              </Card>
              <Card className="rounded-[26px] border-white/70 bg-white/85 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur">
                <CardContent className="p-5">
                  <Smartphone className="mb-4 h-8 w-8 text-amber-600" />
                  <p className="text-sm text-slate-500">Depois</p>
                  <p className="mt-1 text-xl font-semibold">Leitura automática</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="flex justify-center lg:justify-end">
            <div className="w-full max-w-[390px] rounded-[42px] border border-slate-900/10 bg-slate-950 p-3 shadow-[0_40px_100px_rgba(15,23,42,0.30)]">
              <div className="rounded-[34px] bg-[linear-gradient(180deg,#f8fafc_0%,#eef6ff_38%,#f8fafc_100%)] px-4 pb-4 pt-3">
                <div className="mx-auto mb-4 h-1.5 w-24 rounded-full bg-slate-900/70" />

                <div className="rounded-[28px] bg-slate-950 px-4 py-4 text-white shadow-[0_16px_30px_rgba(15,23,42,0.22)]">
                  <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs uppercase tracking-[0.24em] text-sky-200/80">Pesquisa API</p>
                      <p className="mt-1 text-2xl font-semibold">Entender sem complicar</p>
                    </div>
                    <div className="rounded-2xl bg-white/10 p-3">
                      <Link2 className="h-6 w-6 text-sky-200" />
                    </div>
                  </div>
                  <p className="mt-3 text-sm leading-6 text-slate-300">
                    A API serve para trazer os dados mais rápido e ajudar a loja a ver o dinheiro com mais clareza.
                  </p>
                </div>

                <div className="mt-4 grid gap-3">
                  <Card className="rounded-[24px] border-white bg-white/90 shadow-none">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-sm text-slate-500">Regra simples</p>
                          <p className="mt-1 text-lg font-semibold text-slate-950">
                            Dinheiro que entra - gastos - perdas = lucro
                          </p>
                        </div>
                        <div className="rounded-2xl bg-emerald-100 p-3 text-emerald-700">
                          <ShieldCheck className="h-5 w-5" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-2 gap-3">
                    <Card className="rounded-[22px] border-white bg-white/90 shadow-none">
                      <CardContent className="p-4">
                        <p className="text-xs uppercase tracking-[0.18em] text-slate-400">Hoje</p>
                        <p className="mt-2 text-lg font-semibold text-slate-950">Planilha</p>
                        <p className="mt-1 text-xs leading-5 text-slate-500">boa para conferir e organizar</p>
                      </CardContent>
                    </Card>
                    <Card className="rounded-[22px] border-white bg-white/90 shadow-none">
                      <CardContent className="p-4">
                        <p className="text-xs uppercase tracking-[0.18em] text-slate-400">Depois</p>
                        <p className="mt-2 text-lg font-semibold text-slate-950">API</p>
                        <p className="mt-1 text-xs leading-5 text-slate-500">boa para rotina e rapidez</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <SectionCard
                key={section.title}
                title={section.title}
                icon={Icon}
                tone={section.tone}
                points={section.points}
              />
            );
          })}
        </section>

        <section className="grid gap-4 lg:grid-cols-[1fr_0.95fr]">
          <Card className="rounded-[32px] border-white/70 bg-white/85 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="rounded-2xl bg-sky-100 p-3 text-sky-700">
                  <BarChart3 className="h-5 w-5" />
                </div>
                <div>
                  <CardTitle className="text-2xl">API x XLS</CardTitle>
                  <CardDescription>O papel de cada um na conta da loja.</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {compareRows.map((row) => (
                <div key={row.label} className="grid gap-3 rounded-2xl border bg-white p-4 md:grid-cols-[0.7fr_1fr_1fr]">
                  <p className="font-semibold text-slate-900">{row.label}</p>
                  <p className="text-sm text-slate-600">
                    <span className="font-medium text-slate-900">XLS:</span> {row.xls}
                  </p>
                  <p className="text-sm text-slate-600">
                    <span className="font-medium text-slate-900">API:</span> {row.api}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="rounded-[32px] border-white/70 bg-white/85 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="rounded-2xl bg-emerald-100 p-3 text-emerald-700">
                  <RefreshCcw className="h-5 w-5" />
                </div>
                <div>
                  <CardTitle className="text-2xl">Fluxo ideal</CardTitle>
                  <CardDescription>Do dado até a decisão.</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                "1. O Zé Delivery gera os dados da venda.",
                "2. A API ou a planilha trazem esses dados.",
                "3. O sistema organiza a conta no banco.",
                "4. A tela mostra lucro, gasto e perda.",
                "5. O dono age no que mais protege o dinheiro da loja.",
              ].map((item) => (
                <div key={item} className="rounded-2xl border bg-white p-4 text-sm leading-6 text-slate-700">
                  {item}
                </div>
              ))}
              <div className="rounded-2xl border border-dashed bg-slate-50 p-4 text-sm text-slate-600">
                Se faltar base, a planilha continua valendo. Se a API estiver pronta, ela pode assumir a leitura com menos trabalho e mais rapidez.
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </main>
  );
}
