export default {
  plugins: [],
};
